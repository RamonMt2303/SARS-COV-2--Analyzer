library(ggplot2)
library(gganimate)
library(reshape2)
library(dplyr)
library(randomcoloR)

a<-c(8930,8942,8727)
g <- c(5859,5857,5736)
t <- c(9607,9593,9359)
c <- c(5484,5482,5347)
M <- c("África","Brazil","Inglaterra")
n<-3
palette<-c("purple","blue","orange")
palette2<-c("purple","blue","orange")
palette3<-c("purple","blue","orange")
palette4<-c("purple","blue","orange")
palette5<-distinctColorPalette(n)
df <- data.frame(Guanina=g,
                 Citosina=c,
                 Adenina=a,
                 Timina=t,
                 Virus = M)
head(df)

dMelt<-melt(df, id="Virus")

png(file = "Comparación de Timina.png")
gT<-dMelt%>%dplyr::arrange(-value)%>%head(3)
p1<-ggplot(data=gT, aes(x=Virus, y=value))
p1<-p1 + geom_bar(width = 1, stat = "identity", color = "black", fill = palette)
p1<-p1 + theme(legend.position = "none")
p1<-p1 + xlab("Variantes del Sars-Cov-2") + ylab("Timina") 
p1<-p1 + ggtitle("Comparación de Timina")
p1
dev.off()

df2 <- data.frame(Guanina=g,
                  Citosina=c,
                  Adenina=a,
                  Virus = M)
head(df2)

dMelt2<-melt(df2, id="Virus")

png(file = "Comparación de Adenina.png")

gA<-dMelt2%>%dplyr::arrange(-value)%>%head(3)
p2<-ggplot(data=gA, aes(x=Virus, y=value))
p2<-p2 + geom_bar(width = 1, stat = "identity", color = "black", fill = palette2)
p2<-p2 + theme(legend.position = "none")
p2<-p2 + xlab("Variantes del Sars-Cov-2") + ylab("Adenina") 
p2<-p2 + ggtitle("Comparación de Adenina")
p2<-p2 + theme(legend.position = "bottom")
p2<-p2 + scale_fill_discrete(name = "Cantidad de Adenina", 
                             labels = c("A","B","C"))
p2
dev.off()

df3 <- data.frame(Guanina=g,
                  Citosina=c,
                  Virus = M)
head(df3)

dMelt3<-melt(df3, id="Virus")

png(file = "Comparación de Citosina.png")

gC<-dMelt3%>%dplyr::arrange(-value)%>%head(3)
p3<-ggplot(data=gC, aes(x=Virus, y=value))
p3<-p3 + geom_bar(width = 1, stat = "identity", color = "black", fill = palette3)
p3<-p3 + theme(legend.position = "none")
p3<-p3 + xlab("Variantes del Sars-Cov-2") + ylab("Citosina") 
p3<-p3 + ggtitle("Comparación de Citosina")
p3
dev.off()

df4 <- data.frame(Guanina=g,
                  Virus = M)
head(df4)

dMelt4<-melt(df4, id="Virus")

png(file = "Comparación de Guanina.png")

gG<-dMelt4%>%dplyr::arrange(-value)%>%head(3)
p4<-ggplot(data=gC, aes(x=Virus, y=value))
p4<-p4 + geom_bar(width = 1, stat = "identity", color = "black", fill = palette4)
p4<-p4 + theme(legend.position = "none")
p4<-p4 + xlab("Variantes del Sars-Cov-2") + ylab("Guanina") 
p4<-p4 + ggtitle("Comparación de Guanina")
p4
dev.off()

png(file = "Comparación de Timina gráfica de pastel.png")
gTwithMyLabels<-gT%>%
  dplyr::mutate(id = LETTERS[row_number()])

b<-ggplot(data=gTwithMyLabels, aes(x='', y = value, fill = paste0(id,' : ', 
  Virus, ' ( ', round(value/sum(value)*100), "%", ' ) ')))
b<-b + geom_bar(width = 1, stat = "identity", color = "black")
b<-b + geom_text(aes(x = 1.4, label = id), 
                 position = position_stack(vjust = 0.5))
b<-b + theme_void()
b<-b + theme_classic()
b<-b + theme(legend.position = "top")
b<-b + coord_polar("y", start = 0)
b<-b + scale_fill_manual(values = palette)
b<-b + theme(axis.line =element_blank())
b<-b + theme(axis.text =element_blank())
b<-b + theme(axis.ticks =element_blank())
b<-b + labs(x = NULL, y = NULL, fill = NULL)
b<-b + labs(title = "Gráfico en forma de pastel del contenido 
de Timina en las variantes  del Sars-Cov-2")
b<-b + labs(subtitle = "Elaborado por:
Ramón Martínez, Elizabeth Díaz, Diego Reséndiz y Kevin Aguilera")
b
dev.off()

png(file = "Comparación de Adenina gráfica de pastel.png")
gAwithMyLabels<-gA%>%
  dplyr::mutate(id = LETTERS[row_number()])


c<-ggplot(data=gAwithMyLabels, aes(x='', y = value, fill = paste0(id,' : ', 
                                                                  Virus, ' ( ', round(value/sum(value)*100), "%", ' ) ')))
c<-c + geom_bar(width = 1, stat = "identity",color = "black")
c<-c + geom_text(aes(x = 1.4, label = id), 
                 position = position_stack(vjust = 0.5))
c<-c + theme_void()
c<-c + theme_classic()
c<-c + theme(legend.position = "top")
c<-c + coord_polar("y", start = 0)
c<-c + scale_fill_manual(values = palette)
c<-c + theme(axis.line =element_blank())
c<-c + theme(axis.text =element_blank())
c<-c + theme(axis.ticks =element_blank())
c<-c + labs(x = NULL, y = NULL, fill = NULL)
c<-c + labs(title = "Gráfico en forma de pastel del contenido 
de Adenina en las variantes  del Sars-Cov-2")
c<-c + labs(subtitle = "Elaborado por:
Ramón Martínez, Elizabeth Díaz, Diego Reséndiz y Kevin Aguilera")
c
dev.off()

png(file = "Comparación de Citosina gráfica de pastel.png")
gCwithMyLabels<-gC%>%
  dplyr::mutate(id = LETTERS[row_number()])


d<-ggplot(data=gCwithMyLabels, aes(x='', y = value, fill = paste0(id,' : ', 
                                                                  Virus, ' ( ', round(value/sum(value)*100), "%", ' ) ')))
d<-d + geom_bar(width = 1, stat = "identity",color = "black")
d<-d + geom_text(aes(x = 1.4, label = id), 
                 position = position_stack(vjust = 0.5))
d<-d + theme_void()
d<-d + theme_classic()
d<-d + theme(legend.position = "top")
d<-d + coord_polar("y", start = 0)
d<-d + scale_fill_manual(values = palette)
d<-d + theme(axis.line =element_blank())
d<-d + theme(axis.text =element_blank())
d<-d + theme(axis.ticks =element_blank())
d<-d + labs(x = NULL, y = NULL, fill = NULL)
d<-d + labs(title = "Gráfico en forma de pastel del contenido 
de Citosina en las variantes  del Sars-Cov-2")
d<-d + labs(subtitle = "Elaborado por:
Ramón Martínez, Elizabeth Díaz, Diego Reséndiz y Kevin Aguilera")
d
dev.off()

png(file = "Comparación de Guanina gráfica de pastel.png")
gGwithMyLabels<-gG%>%
  dplyr::mutate(id = LETTERS[row_number()])


e<-ggplot(data=gGwithMyLabels, aes(x='', y = value, fill = paste0(id,' : ', 
                                                                  Virus, ' ( ', round(value/sum(value)*100), "%", ' ) ')))
e<-e + geom_bar(width = 1, stat = "identity",color = "black")
e<-e + geom_text(aes(x = 1.4, label = id), 
                 position = position_stack(vjust = 0.5))
e<-e + theme_void()
e<-e + theme_classic()
e<-e + theme(legend.position = "top")
e<-e + coord_polar("y", start = 0)
e<-e + scale_fill_manual(values = palette)
e<-e + theme(axis.line =element_blank())
e<-e + theme(axis.text =element_blank())
e<-e + theme(axis.ticks =element_blank())
e<-e + labs(x = NULL, y = NULL, fill = NULL)
e<-e + labs(title = "Gráfico en forma de pastel del contenido 
de Guanina en las variantes  del Sars-Cov-2")
e<-e + labs(subtitle = "Elaborado por:
Ramón Martínez, Elizabeth Díaz, Diego Reséndiz y Kevin Aguilera")
e
dev.off()
