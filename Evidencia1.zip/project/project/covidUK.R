library(collapse)
library(stringr)
library(Biostrings)
library(bios2mds)

DividirARN<-function(rna_UK,n1){
  j <- gl(n = n1/3, k = 3)
  j
  m<-split(rna_UK, j)
  as.matrix(m)
  as.data.frame(m)
}

MatrizTorna<-function(rev_strand,n1){
  j <- gl(n =n1/3 , k = 3)
  j
  m<-split(rev_strand, j)
  as.matrix(m)
  as.data.frame(m)
}

dnatorna<-function(dna_UK){
  dna_UK[dna_UK=="T"]="U"
  DNA2=dna_UK
  dna_UK[dna_UK=="T"]="T"
  return (DNA2)
}

porcentaje<-function(dna_UK){
  ContA<-0;
  ContT<-0;
  ContG<-0;
  ContC<-0;
  for (i in dna_UK){
    if ( i=="A"){
      ContA<-ContA+1;
    }
    else if ( i=="T"){
      ContT<-ContT+1;
    }
    else if (i=="C"){
      ContC<-ContC+1;
    }
    else if (i=="G"){
      ContG<-ContG+1;
    }
  }
  PorA<-ContA/length(dna_UK)*100
  PorG<-ContG/length(dna_UK)*100
  PorT<-ContT/length(dna_UK)*100
  PorC<-ContC/length(dna_UK)*100
  print(ContA)
  print(PorA)
  print(ContG)
  print(PorG)
  print(ContT)
  print(PorT)
  print(ContC)
  print(PorC)
  GC<-PorG+PorC;
  print("GC")
  print(GC)
}

MatrizProteinas<-function(h,n1){
  cont<-1
  cont2<-1
  x<-vector(mode="character")
  while(cont<=n1/3){
    o1<-h[,cont2]
    o_coll<-str_c(o1, collapse="")
    if (o_coll == "UUU" || o_coll == "UUC"){
      proteina<-"F"
      x<-append(x,proteina)
    }else if (o_coll == "UUA" || o_coll == "UUG" || o_coll == "CUU" ||
              o_coll == "CUC"|| o_coll == "CUA" || o_coll == "CUG"){
      proteina<-"L"
      x<-append(x,proteina)
    }else if (o_coll == "AUU" || o_coll == "AUC" || o_coll == "AUA" 
              || o_coll == "AUG"){
      proteina<-"I"
      x<-append(x,proteina)
    }else if (o_coll == "GUU" || o_coll == "GUC" || o_coll == "GUA" ||
              o_coll == "GUG"){
      proteina<-"V"
      x<-append(x,proteina)
    }else if (o_coll == "UCU" || o_coll == "UCC" || o_coll == "UCA" ||
              o_coll == "UCG"){
      proteina<-"S"
      x<-append(x,proteina)
    }else if (o_coll == "CCU" || o_coll == "CCC" || o_coll == "CCA" || 
              o_coll == "CCG"){
      proteina<-"P"
      x<-append(x,proteina)
    }else if (o_coll == "ACU" || o_coll == "ACC" || o_coll == "ACA" || 
              o_coll == "ACG"){
      proteina<-"T"
      x<-append(x,proteina)
    }else if (o_coll == "GCU" || o_coll == "GCC" || o_coll == "GCA" || 
              o_coll == "GCG"){
      proteina<-"A"
      x<-append(x,proteina)
    }else if (o_coll == "UAU" || o_coll == "UAC"){
      proteina<-"Y"
      x<-append(x,proteina)
    }else if (o_coll == "CAU" || o_coll == "CAC"){
      proteina<-"H"
      x<-append(x,proteina)
    }else if (o_coll == "CAA" || o_coll == "CAG"){
      proteina<-"G"
      x<-append(x,proteina)
    }else if (o_coll == "AAU" || o_coll == "AAC"){
      proteina<-"N"
      x<-append(x,proteina)
    }else if (o_coll == "AAA" || o_coll == "AAG"){
      proteina<-"K"
      x<-append(x,proteina)
    }else if (o_coll == "GAU" || o_coll == "GAC"){
      proteina<-"D"
      x<-append(x,proteina)
    }else if (o_coll == "GAA" || o_coll == "GAG"){
      proteina<-"E"
      x<-append(x,proteina)
    }else if (o_coll == "UGU" || o_coll == "UGC"){
      proteina<-"C"
      x<-append(x,proteina)
    }else if (o_coll == "UGG"){
      proteina<-"W"
      x<-append(x,proteina)
    }else if (o_coll == "CGU" || o_coll == "CGC" || o_coll == "CGA" ||
              o_coll == "CGG" || o_coll == "AGA" || o_coll == "AGG"){
      proteina<-"R"
      x<-append(x,proteina)
    }else if (o_coll == "AGU" || o_coll == "AGC"){
      proteina<-"S"
      x<-append(x,proteina)
    }else if (o_coll == "GGU" || o_coll == "GGC" || o_coll == "GGA" ||
              o_coll == "GGG"){
      proteina<-"G"
      x<-append(x,proteina)
    }
    cont2 = cont2+1
    cont = cont+1
  }
  return(x)
}
contar_DNA<-function(dna_UK){
  
  return (length(dna_UK))
}
dna_fasta<-import.fasta(file = "CovidUK.fasta", aa.to.upper = TRUE, 
                        gap.to.dash = TRUE)
dna_UK<-paste(dna_fasta[["MW980115.1"]])
n1<-contar_DNA(dna_UK)
rna_UK<-dnatorna(dna_UK)
h<-DividirARN(rna_UK,n1)
h
MatrizProteinas(h,n1)
porcentaje(dna_UK)
rev_strand <- rev(rna_UK)
ARNinverso <- MatrizTorna(rev_strand, n1)
write.table(
  ARNinverso,
  file = "Secuencia de ARN inverso de la variante Inglesa.txt",
  append = FALSE,
  quote = FALSE,
  sep = ","
)
